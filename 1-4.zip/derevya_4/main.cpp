#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

// бинарное дерево поиска целых чисел.
// умеет вставлять числа и считать свой диаметр.
class BinaryTree {
public:
    BinaryTree() {
        root = nullptr;
    }

    ~BinaryTree() {
        destroy(root);
    }

    // вставляем число: меньше - идём влево, иначе вправо.
    void insert(int value) {
        root = insertNode(root, value);
    }

    // диаметр это самый длинный путь между двумя узлами,
    // измеренный в количестве рёбер.
    int diameter() {
        int best = 0;
        height(root, best);
        return best;
    }

    // печать дерева по возрастанию (симметричный обход).
    void printInOrder() const {
        printInOrder(root);
        cout << "\n";
    }

private:
    struct Node {
        int value;
        Node* left;
        Node* right;
    };
    Node* root;

    Node* insertNode(Node* node, int value) {
        if (node == nullptr) {
            Node* fresh = new Node;
            fresh->value = value;
            fresh->left = nullptr;
            fresh->right = nullptr;
            return fresh;
        }
        if (value < node->value) node->left = insertNode(node->left, value);
        else node->right = insertNode(node->right, value);
        return node;
    }

    // считаем высоту поддерева и по пути обновляем лучший диаметр.
    // диаметр через узел = высота левого поддерева + высота правого.
    int height(Node* node, int& best) {
        if (node == nullptr) return 0;
        int leftHeight = height(node->left, best);
        int rightHeight = height(node->right, best);
        int through = leftHeight + rightHeight;
        if (through > best) best = through;
        int bigger = leftHeight > rightHeight ? leftHeight : rightHeight;
        return bigger + 1;
    }

    void printInOrder(Node* node) const {
        if (node == nullptr) return;
        printInOrder(node->left);
        cout << node->value << " ";
        printInOrder(node->right);
    }

    void destroy(Node* node) {
        if (node == nullptr) return;
        destroy(node->left);
        destroy(node->right);
        delete node;
    }
};

int main() {
    srand(time(0));

    BinaryTree tree;
    int count = 10;
    // вставляем случайные числа от 0 до 99.
    for (int i = 0; i < count; i++) {
        tree.insert(rand() % 100);
    }

    cout << "Derevo (po vozrastaniju): ";
    tree.printInOrder();

    cout << "Diametr (chislo reber): " << tree.diameter() << "\n";

    return 0;
}
