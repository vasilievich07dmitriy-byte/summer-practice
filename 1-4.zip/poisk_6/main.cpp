#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// простой растущий массив строк без вектора.
// сами управляем памятью через new[] и delete[].
class WordList {
public:
    WordList() {
        cap = 4;
        len = 0;
        data = new string[cap];
    }

    ~WordList() {
        delete[] data;
    }

    // добавляем слово. если места не хватает - выделяем вдвое больше.
    void add(const string& word) {
        if (len == cap) {
            cap = cap * 2;
            string* nd = new string[cap];
            for (int i = 0; i < len; i++) nd[i] = data[i];
            delete[] data;
            data = nd;
        }
        data[len] = word;
        len++;
    }

    string get(int i) const {
        return data[i];
    }

    int size() const {
        return len;
    }

private:
    string* data;
    int cap;
    int len;
};

// проверяем: поместятся ли все слова в maxLines строк при ширине width.
// идём по словам по порядку, кладём в текущую строку пока влезают
// (с одним пробелом между словами), иначе начинаем новую строку.
bool canFit(const WordList& words, int width, int maxLines) {
    int lines = 1;
    int currentLen = 0;
    for (int i = 0; i < words.size(); i++) {
        int wordLen = (int)words.get(i).size();
        // одно слово длиннее ширины - не поместится никак.
        if (wordLen > width) return false;
        if (currentLen == 0) {
            currentLen = wordLen;
        } else if (currentLen + 1 + wordLen <= width) {
            currentLen = currentLen + 1 + wordLen;
        } else {
            lines++;
            currentLen = wordLen;
        }
    }
    return lines <= maxLines;
}

// печатаем слова с переносами при заданной ширине.
void printWrapped(const WordList& words, int width) {
    int currentLen = 0;
    for (int i = 0; i < words.size(); i++) {
        int wordLen = (int)words.get(i).size();
        if (currentLen == 0) {
            cout << words.get(i);
            currentLen = wordLen;
        } else if (currentLen + 1 + wordLen <= width) {
            cout << " " << words.get(i);
            currentLen = currentLen + 1 + wordLen;
        } else {
            cout << "\n" << words.get(i);
            currentLen = wordLen;
        }
    }
    cout << "\n";
}

int main() {
    WordList words;
    ifstream file("slova.txt");
    string word;
    // читаем слова из файла по одному.
    while (file >> word) {
        words.add(word);
    }
    file.close();

    if (words.size() == 0) {
        cout << "Fajl pust ili ne najden\n";
        return 0;
    }

    int maxLines;
    cout << "Vvedite maksimalnoe chislo strok X: ";
    cin >> maxLines;

    // границы для двоичного поиска ширины:
    // минимум это длина самого длинного слова (иначе оно не влезет),
    // максимум это все слова в одну строку с пробелами.
    int low = 0;
    int high = 0;
    for (int i = 0; i < words.size(); i++) {
        int wordLen = (int)words.get(i).size();
        if (wordLen > low) low = wordLen;
        high = high + wordLen + 1;
    }

    // двоичный поиск минимальной ширины, при которой всё влезает в X строк.
    int answer = high;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (canFit(words, mid, maxLines)) {
            answer = mid;
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }

    cout << "Minimalnaja shirina: " << answer << "\n";
    cout << "Rezultat:\n";
    printWrapped(words, answer);

    return 0;
}
