#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

// двусвязный список целых чисел.
// каждый узел знает соседа слева (prev) и справа (next).
// сами управляем памятью, поэтому в деструкторе всё удаляем.
class DoublyList {
public:
    DoublyList() {
        head = nullptr;
        tail = nullptr;
    }

    ~DoublyList() {
        Node* cur = head;
        while (cur != nullptr) {
            Node* nxt = cur->next;
            delete cur;
            cur = nxt;
        }
    }

    // добавляем число в конец списка.
    void addBack(int value) {
        Node* node = new Node;
        node->value = value;
        node->next = nullptr;
        node->prev = tail;
        if (tail == nullptr) head = node;
        else tail->next = node;
        tail = node;
    }

    // печать всего списка через тире: 1 - 2 - 4 - 5
    void print() const {
        Node* cur = head;
        while (cur != nullptr) {
            cout << cur->value;
            if (cur->next != nullptr) cout << " - ";
            cur = cur->next;
        }
        cout << "\n";
    }

    // ищем пары узлов, у которых сумма значений равна k.
    // список отсортирован по неубыванию, поэтому идём с двух концов:
    // левый указатель с начала, правый с конца.
    // если сумма мала - двигаем левый вправо, если велика - правый влево.
    void printPairsWithSum(int k) const {
        Node* left = head;
        Node* right = tail;
        bool found = false;
        while (left != nullptr && right != nullptr && left != right && left->prev != right) {
            int sum = left->value + right->value;
            if (sum == k) {
                cout << left->value << " + " << right->value << " = " << k << "\n";
                found = true;
                left = left->next;
                right = right->prev;
            } else if (sum < k) {
                left = left->next;
            } else {
                right = right->prev;
            }
        }
        if (!found) cout << "Net takih par\n";
    }

private:
    struct Node {
        int value;
        Node* next;
        Node* prev;
    };
    Node* head;
    Node* tail;
};

int main() {
    srand(time(0));

    DoublyList list;
    // заполняем список случайными числами по неубыванию.
    // каждое следующее число не меньше предыдущего.
    int current = rand() % 3;
    int count = 7;
    for (int i = 0; i < count; i++) {
        list.addBack(current);
        current = current + rand() % 3 + 1;
    }

    cout << "Spisok: ";
    list.print();

    int k;
    cout << "Vvedite k: ";
    cin >> k;

    cout << "Pary s summoj " << k << ":\n";
    list.printPairsWithSum(k);

    return 0;
}
