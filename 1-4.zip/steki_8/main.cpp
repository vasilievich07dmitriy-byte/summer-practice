#include <iostream>
#include <string>

using namespace std;

// свой стек строк без вектора.
// внутри односвязный список: верхушка это последний добавленный узел.
class StringStack {
public:
    StringStack() {
        topNode = nullptr;
        count = 0;
    }

    ~StringStack() {
        clear();
    }

    // кладём элемент на верхушку.
    void push(const string& value) {
        Node* node = new Node;
        node->value = value;
        node->next = topNode;
        topNode = node;
        count++;
    }

    // снимаем верхний элемент и возвращаем его значение.
    string pop() {
        string value = topNode->value;
        Node* nxt = topNode->next;
        delete topNode;
        topNode = nxt;
        count--;
        return value;
    }

    bool empty() const {
        return topNode == nullptr;
    }

    int size() const {
        return count;
    }

    // полностью очищаем стек.
    void clear() {
        while (topNode != nullptr) {
            Node* nxt = topNode->next;
            delete topNode;
            topNode = nxt;
        }
        count = 0;
    }

private:
    struct Node {
        string value;
        Node* next;
    };
    Node* topNode;
    int count;
};

// история браузера на двух стеках: "назад" и "вперёд".
// текущий адрес храним отдельно.
class BrowserHistory {
public:
    BrowserHistory(const string& homepage) {
        current = homepage;
    }

    // переходим на новый адрес. текущий уходит в стек "назад",
    // а история "вперёд" очищается (как в настоящем браузере).
    void visit(const string& url) {
        backStack.push(current);
        current = url;
        forwardStack.clear();
    }

    // шаг назад несколько раз. если идти некуда - останавливаемся.
    void backward(int steps) {
        for (int i = 0; i < steps; i++) {
            if (backStack.empty()) break;
            forwardStack.push(current);
            current = backStack.pop();
        }
    }

    // шаг вперёд несколько раз.
    void forward(int steps) {
        for (int i = 0; i < steps; i++) {
            if (forwardStack.empty()) break;
            backStack.push(current);
            current = forwardStack.pop();
        }
    }

    string now() const {
        return current;
    }

private:
    StringStack backStack;
    StringStack forwardStack;
    string current;
};

int main() {
    BrowserHistory history("Homepage");
    cout << "Start: " << history.now() << "\n";

    history.visit("google.com");
    history.visit("notion.so");
    history.visit("github.com");
    cout << "Posle 3 perehodov: " << history.now() << "\n";

    history.backward(1);
    cout << "Nazad na 1: " << history.now() << "\n";

    history.backward(2);
    cout << "Nazad na 2: " << history.now() << "\n";

    history.forward(1);
    cout << "Vpered na 1: " << history.now() << "\n";

    history.visit("wikipedia.org");
    cout << "Novyj perehod: " << history.now() << "\n";

    history.forward(1);
    cout << "Vpered posle novogo perehoda (nekuda): " << history.now() << "\n";

    return 0;
}
