﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Queue.h"

int main() {

    setlocale(LC_ALL, "Russian");

    srand(time(0));

    Queue queue;
    int choice;

    do {
        std::cout << "\n====================================\n";
        std::cout << "Текущая очередь: ";
        queue.print();
        std::cout << "====================================\n";
        std::cout << "1. Заполнить случайными числами\n";
        std::cout << "2. Добавить элемент в конец (enqueue)\n";
        std::cout << "3. Удалить элемент из начала (dequeue)\n";
        std::cout << "4. Показать первый элемент\n";
        std::cout << "5. Очистить очередь\n";
        std::cout << "0. Выход\n";
        std::cout << "Выберите действие: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                int count;
                std::cout << "Сколько элементов добавить? ";
                std::cin >> count;
                queue.fillRandom(count);
                std::cout << "Очередь заполнена!\n";
                break;
            }
            case 2: {
                int value;
                std::cout << "Введите число: ";
                std::cin >> value;
                queue.enqueue(value);
                break;
            }
            case 3:
                queue.dequeue();
                break;
            case 4:
                if (!queue.isEmpty()) {
                    std::cout << "Первый элемент: " << queue.getFront() << "\n";
                } else {
                    std::cout << "Очередь пуста!\n";
                }
                break;
            case 5:
                queue.clear();
                std::cout << "Очередь очищена.\n";
                break;
            case 0:
                std::cout << "Завершение работы...\n";
                break;
            default:
                std::cout << "Неверный пункт меню, попробуйте снова.\n";
                break;
        }
    } while (choice != 0);

    return 0;
}
