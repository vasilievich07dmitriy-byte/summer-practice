﻿#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <cstdlib> // Для функций rand() и srand()
#include <ctime>   // Для функции time()

class Queue {
private:
    // Структура для узла списка
    struct Node {
        int data;
        Node* next;

        // Конструктор узла
        Node(int value) {
            data = value;
            next = nullptr;
        }
    };

    Node* head; // Указатель на начало очереди (откуда забираем)
    Node* tail; // Указатель на конец очереди (куда добавляем)

public:
    // Конструктор очереди по умолчанию
    Queue() {
        head = nullptr;
        tail = nullptr;
    }

    // Деструктор (вызывается автоматически и очищает всю память)
    ~Queue() {
        clear();
    }

    // Проверка, пуста ли очередь
    bool isEmpty() const {
        return head == nullptr;
    }

    // 1. Вставка нового элемента в конец
    void enqueue(int value) {
        Node* newNode = new Node(value);
        
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    // 2. Удаление элемента из начала
    void dequeue() {
        if (isEmpty()) {
            std::cout << "Ошибка: Очередь пуста, удалять нечего!\n";
            return;
        }

        Node* temp = head;     // Запоминаем первый узел
        head = head->next;     // Сдвигаем начало на следующий узел
        
        // Если после удаления элементов не осталось, обнуляем и tail
        if (head == nullptr) {
            tail = nullptr;
        }

        delete temp;           // Освобождаем память
    }

    // Получение значения из начала очереди (без удаления)
    int getFront() const {
        if (isEmpty()) {
            std::cout << "Очередь пуста!\n";
            return 0;
        }
        return head->data;
    }

    // Очистка всей очереди
    void clear() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    // Заполнение очереди случайными числами
    void fillRandom(int count) {
        for (int i = 0; i < count; ++i) {
            // Генерируем случайное число от -50 до 50
            int randomValue = rand() % 101 - 50;
            enqueue(randomValue);
        }
    }

    // Вывод очереди на экран
    void print() const {
        if (isEmpty()) {
            std::cout << "[ Очередь пуста ]\n";
            return;
        }

        Node* current = head;
        std::cout << "НАЧАЛО -> ";
        while (current != nullptr) {
            std::cout << current->data << " ";
            current = current->next;
        }
        std::cout << "<- КОНЕЦ\n";
    }
};

#endif // QUEUE_H
