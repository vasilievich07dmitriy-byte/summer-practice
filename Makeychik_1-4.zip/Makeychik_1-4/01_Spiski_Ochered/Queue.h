﻿#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <cstdlib>
#include <ctime>

class Queue {
private:

    struct Node {
        int data;
        Node* next;

        Node(int value) {
            data = value;
            next = nullptr;
        }
    };

    Node* head;
    Node* tail;

public:

    Queue() {
        head = nullptr;
        tail = nullptr;
    }

    ~Queue() {
        clear();
    }

    bool isEmpty() const {
        return head == nullptr;
    }

    void enqueue(int value) {
        Node* newNode = new Node(value);

        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    void dequeue() {
        if (isEmpty()) {
            std::cout << "Ошибка: Очередь пуста, удалять нечего!\n";
            return;
        }

        Node* temp = head;
        head = head->next;

        if (head == nullptr) {
            tail = nullptr;
        }

        delete temp;
    }

    int getFront() const {
        if (isEmpty()) {
            std::cout << "Очередь пуста!\n";
            return 0;
        }
        return head->data;
    }

    void clear() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    void fillRandom(int count) {
        for (int i = 0; i < count; ++i) {

            int randomValue = rand() % 101 - 50;
            enqueue(randomValue);
        }
    }

    void print() const {
        if (isEmpty()) {
            std::cout << "[ Очередь пуста ]\n";
            return;
        }

        Node* current = head;
        std::cout << "НАЧАЛО -> ";
        while (current != nullptr) {
            std::cout << current->data << " ";
            current = current->next;
        }
        std::cout << "<- КОНЕЦ\n";
    }
};

#endif
