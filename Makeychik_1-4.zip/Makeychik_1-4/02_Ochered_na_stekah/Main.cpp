﻿#include <iostream>
#include <limits>
#include "Task10_QueueOnStacks.hpp"

using namespace DataStructures;

void clearBuffer() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int main() {
    setlocale(LC_ALL, "Russian");

    QueueOnStacks queue;
    int choice;

    std::cout << "=========================================================\n";
    std::cout << "  Задача 10: Реализация Очереди на основе двух Стеков\n";
    std::cout << "=========================================================\n";

    while (true) {
        std::cout << "\nТекущее состояние (Размер: " << queue.size() << "): ";
        queue.print();

        std::cout << "\n--- МЕНЮ ---\n";
        std::cout << "1. Добавить элемент в конец (enqueue)\n";
        std::cout << "2. Удалить элемент из начала (dequeue)\n";
        std::cout << "3. Посмотреть первый элемент (front)\n";
        std::cout << "4. Очистить очередь\n";
        std::cout << "0. Выход\n";
        std::cout << "Выберите действие: ";

        if (!(std::cin >> choice)) {
            std::cout << "Некорректный ввод!\n";
            clearBuffer();
            continue;
        }

        try {
            switch (choice) {
                case 1: {
                    int val;
                    std::cout << "Введите число для добавления: ";
                    if (std::cin >> val) {
                        queue.enqueue(val);
                        std::cout << "Элемент " << val << " добавлен.\n";
                    } else {
                        clearBuffer();
                    }
                    break;
                }
                case 2: {
                    int removed = queue.dequeue();
                    std::cout << "Удален элемент: " << removed << "\n";
                    break;
                }
                case 3: {
                    std::cout << "Первый элемент в очереди: " << queue.front() << "\n";
                    break;
                }
                case 4: {
                    queue.clear();
                    std::cout << "Очередь полностью очищена.\n";
                    break;
                }
                case 0:
                    std::cout << "Завершение работы программы...\n";
                    return 0;
                default:
                    std::cout << "Неверный пункт меню.\n";
                    break;
            }
        } catch (const std::exception& ex) {
            std::cerr << "\n[ИСКЛЮЧЕНИЕ]: " << ex.what() << "\n";
        }
    }
}
