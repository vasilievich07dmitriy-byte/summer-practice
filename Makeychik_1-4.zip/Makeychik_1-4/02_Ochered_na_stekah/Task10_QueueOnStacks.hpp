﻿#ifndef TASK10_QUEUE_ON_STACKS_HPP
#define TASK10_QUEUE_ON_STACKS_HPP

#include <iostream>
#include <stdexcept>
#include <utility>

namespace DataStructures {

    /**
     * @brief Вспомогательный класс «Стек» на основе односвязного списка.
     */
    class Stack {
    private:
        struct Node {
            int data;
            Node* next;
            explicit Node(int val, Node* nextNode = nullptr) 
                : data(val), next(nextNode) {}
        };

        Node* top_;
        size_t size_;

    public:
        Stack() : top_(nullptr), size_(0) {}

        ~Stack() {
            clear();
        }

        // Конструктор копирования
        Stack(const Stack& other) : top_(nullptr), size_(0) {
            if (other.top_ == nullptr) return;
            
            // Копируем элементы в правильном порядке
            Node* otherCurrent = other.top_;
            Node* tail = nullptr;
            while (otherCurrent != nullptr) {
                Node* newNode = new Node(otherCurrent->data);
                if (top_ == nullptr) {
                    top_ = newNode;
                    tail = newNode;
                } else {
                    tail->next = newNode;
                    tail = newNode;
                }
                otherCurrent = otherCurrent->next;
            }
            size_ = other.size_;
        }

        // Оператор присваивания (copy-and-swap)
        Stack& operator=(const Stack& other) {
            if (this != &other) {
                Stack temp(other);
                swap(temp);
            }
            return *this;
        }

        // Конструктор перемещения
        Stack(Stack&& other) noexcept : top_(other.top_), size_(other.size_) {
            other.top_ = nullptr;
            other.size_ = 0;
        }

        // Оператор перемещения
        Stack& operator=(Stack&& other) noexcept {
            if (this != &other) {
                clear();
                top_ = other.top_;
                size_ = other.size_;
                other.top_ = nullptr;
                other.size_ = 0;
            }
            return *this;
        }

        void swap(Stack& other) noexcept {
            std::swap(top_, other.top_);
            std::swap(size_, other.size_);
        }

        void push(int value) {
            top_ = new Node(value, top_);
            ++size_;
        }

        int pop() {
            if (isEmpty()) {
                throw std::runtime_error("Ошибка: Попытка pop() из пустого стека.");
            }
            Node* temp = top_;
            int val = temp->data;
            top_ = top_->next;
            delete temp;
            --size_;
            return val;
        }

        int top() const {
            if (isEmpty()) {
                throw std::runtime_error("Ошибка: Стек пуст.");
            }
            return top_->data;
        }

        bool isEmpty() const noexcept { return top_ == nullptr; }
        size_t size() const noexcept { return size_; }

        void clear() noexcept {
            while (!isEmpty()) {
                Node* temp = top_;
                top_ = top_->next;
                delete temp;
            }
            size_ = 0;
        }
    };

    /**
     * @brief Класс «Очередь», реализованный на базе двух стеков.
     */
    class QueueOnStacks {
    private:
        Stack inStack_;  // Стек для добавления элементов (Вход)
        Stack outStack_; // Стек для извлечения элементов (Выход)

        // Перекладывает элементы из inStack_ в outStack_, если outStack_ пуст
        void transferIfNeeded() {
            if (outStack_.isEmpty()) {
                while (!inStack_.isEmpty()) {
                    outStack_.push(inStack_.pop());
                }
            }
        }

    public:
        QueueOnStacks() = default;
        ~QueueOnStacks() = default; // Компилятор автоматически вызовет деструкторы для inStack_ и outStack_

        /**
         * @brief Добавление элемента в конец очереди. Сложность O(1).
         */
        void enqueue(int value) {
            inStack_.push(value);
        }

        /**
         * @brief Удаление элемента из начала очереди. Амортизированная сложность O(1).
         */
        int dequeue() {
            if (isEmpty()) {
                throw std::runtime_error("Ошибка: Попытка извлечения из пустой очереди.");
            }
            transferIfNeeded();
            return outStack_.pop();
        }

        /**
         * @brief Просмотр первого элемента очереди без удаления.
         */
        int front() {
            if (isEmpty()) {
                throw std::runtime_error("Ошибка: Очередь пуста.");
            }
            transferIfNeeded();
            return outStack_.top();
        }

        bool isEmpty() const noexcept {
            return inStack_.isEmpty() && outStack_.isEmpty();
        }

        size_t size() const noexcept {
            return inStack_.size() + outStack_.size();
        }

        void clear() noexcept {
            inStack_.clear();
            outStack_.clear();
        }

        /**
         * @brief Вывод состояния очереди (для демонстрации в консоли).
         */
        void print() {
            if (isEmpty()) {
                std::cout << "[ Очередь пуста ]\n";
                return;
            }
            transferIfNeeded();
            
            // Во временный стек скопируем outStack_, чтобы распечатать элементы по порядку
            Stack tempOut = outStack_;
            std::cout << "НАЧАЛО -> ";
            while (!tempOut.isEmpty()) {
                std::cout << tempOut.pop() << " ";
            }

            // Выведем элементы из inStack_ в обратном порядке (так как они лежат на дне)
            Stack tempIn;
            Stack copyIn = inStack_;
            while (!copyIn.isEmpty()) {
                tempIn.push(copyIn.pop());
            }
            while (!tempIn.isEmpty()) {
                std::cout << tempIn.pop() << " ";
            }
            std::cout << "<- КОНЕЦ\n";
        }
    };

} // namespace DataStructures

#endif // TASK10_QUEUE_ON_STACKS_HPP
