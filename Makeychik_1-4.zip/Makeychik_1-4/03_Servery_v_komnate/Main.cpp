﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include "ServerRoom.h"

int main() {
    setlocale(LC_ALL, "Russian");
    srand(time(0));

    int n, m;
    std::cout << "=================================================\n";
    std::cout << "  Задача 13: Анализ соединений серверов в комнате\n";
    std::cout << "=================================================\n";
    std::cout << "Введите длину комнаты (строки N): ";
    std::cin >> n;
    std::cout << "Введите ширину комнаты (столбцы M): ";
    std::cin >> m;

    if (n <= 0 || m <= 0) {
        std::cout << "Размеры комнаты должны быть положительными числами!\n";
        return 1;
    }

    ServerRoom room(n, m);
    std::cout << "По условию в комнате должно быть " << room.getExpectedServerCount() << " серверов (N+M-2).\n";

    int choice;
    do {
        room.printRoom();
        std::cout << "\n--- МЕНЮ ---\n";
        std::cout << "1. Разместить серверы случайно\n";
        std::cout << "2. Ввести координаты серверов вручную\n";
        std::cout << "3. Провести анализ сети (найти соединенные/изолированные)\n";
        std::cout << "4. Очистить комнату\n";
        std::cout << "0. Выход\n";
        std::cout << "Выберите действие: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                room.placeServersRandomly();
                std::cout << "Серверы успешно размещены!\n";
                break;
            case 2: {
                room.clearRoom();
                int count = room.getExpectedServerCount();
                std::cout << "Введите координаты (строка столбец) для " << count << " серверов:\n";
                for (int i = 0; i < count; ++i) {
                    int r, c;
                    std::cout << "Сервер #" << (i + 1) << ": ";
                    std::cin >> r >> c;
                    if (!room.addServerManual(r, c)) {
                        i--;
                    }
                }
                break;
            }
            case 3:
                room.analyzeNetwork();
                break;
            case 4:
                room.clearRoom();
                std::cout << "Комната очищена.\n";
                break;
            case 0:
                std::cout << "Завершение работы...\n";
                break;
            default:
                std::cout << "Неверный ввод!\n";
                break;
        }
    } while (choice != 0);

    return 0;
}
