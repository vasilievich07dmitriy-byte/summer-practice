﻿#ifndef SERVER_ROOM_H
#define SERVER_ROOM_H

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

class ServerRoom {
private:
    int rows;
    int cols;
    int serverCount;
    std::vector<std::vector<int>> grid;

public:

    ServerRoom(int r, int c) {
        rows = r;
        cols = c;
        serverCount = rows + cols - 2;

        if (serverCount > rows * cols) {
            serverCount = rows * cols;
        }

        grid.assign(rows, std::vector<int>(cols, 0));
    }

    void clearRoom() {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                grid[i][j] = 0;
            }
        }
    }

    void placeServersRandomly() {
        clearRoom();
        int placed = 0;
        while (placed < serverCount) {
            int r = rand() % rows;
            int c = rand() % cols;
            if (grid[r][c] == 0) {
                grid[r][c] = 1;
                placed++;
            }
        }
    }

    bool addServerManual(int r, int c) {
        if (r < 0 || r >= rows || c < 0 || c >= cols) {
            std::cout << "Ошибка: Координаты выходят за пределы комнаты!\n";
            return false;
        }
        grid[r][c] = 1;
        return true;
    }

    void analyzeNetwork() const {
        std::vector<int> rowCount(rows, 0);
        std::vector<int> colCount(cols, 0);
        int totalServers = 0;

        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (grid[i][j] == 1) {
                    rowCount[i]++;
                    colCount[j]++;
                    totalServers++;
                }
            }
        }

        int connected = 0;
        int isolated = 0;

        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (grid[i][j] == 1) {

                    if (rowCount[i] > 1 || colCount[j] > 1) {
                        connected++;
                    } else {
                        isolated++;
                    }
                }
            }
        }

        std::cout << "\n--- РЕЗУЛЬТАТЫ АНАЛИЗА ---\n";
        std::cout << "Всего серверов в комнате: " << totalServers << "\n";
        std::cout << "Соединены друг с другом:  " << connected << "\n";
        std::cout << "Изолированы от сети:      " << isolated << "\n";
        std::cout << "--------------------------\n";
    }

    void printRoom() const {
        std::cout << "\nКарта комнаты (" << rows << "x" << cols << ") [S - сервер, . - пусто]:\n  ";
        for (int j = 0; j < cols; ++j) std::cout << j << " ";
        std::cout << "\n";

        for (int i = 0; i < rows; ++i) {
            std::cout << i << " ";
            for (int j = 0; j < cols; ++j) {
                if (grid[i][j] == 1) {
                    std::cout << "S ";
                } else {
                    std::cout << ". ";
                }
            }
            std::cout << "\n";
        }
    }

    int getExpectedServerCount() const { return serverCount; }
};

#endif
