﻿#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "RandomChecker.h"

int main() {
    setlocale(LC_ALL, "Russian");
    srand(time(0));

    RandomChecker checker;
    int choice;

    std::cout << "=========================================================\n";
    std::cout << "  Задача 9*: Проверка генератора случайных чисел\n";
    std::cout << "=========================================================\n";

    do {
        std::cout << "\nТекущий массив чисел (" << checker.size() << " шт.): ";
        checker.printNumbers();

        std::cout << "\n--- МЕНЮ ---\n";
        std::cout << "1. Сгенерировать случайный массив от Антона\n";
        std::cout << "2. Ввести массив вручную (для проверки тестов)\n";
        std::cout << "3. Провести проверку Бориса (бинарным поиском)\n";
        std::cout << "0. Выход\n";
        std::cout << "Выберите действие: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                int n, minVal, maxVal;
                std::cout << "Введите количество чисел N: ";
                std::cin >> n;
                std::cout << "Введите диапазон генерации (min max через пробел): ";
                std::cin >> minVal >> maxVal;
                checker.generateRandom(n, minVal, maxVal);
                std::cout << "Массив успешно создан!\n";
                break;
            }
            case 2: {
                int n;
                std::cout << "Сколько чисел хотите ввести? ";
                std::cin >> n;
                std::vector<int> manualInput(n);
                std::cout << "Введите " << n << " чисел через пробел: ";
                for (int i = 0; i < n; ++i) {
                    std::cin >> manualInput[i];
                }
                checker.setNumbers(manualInput);
                std::cout << "Массив сохранён!\n";
                break;
            }
            case 3: {
                if (checker.size() == 0) {
                    std::cout << "Сначала создайте или введите массив!\n";
                    break;
                }
                int x, y;
                std::cout << "Введите X (минимально допустимое число элементов в окне): ";
                std::cin >> x;
                std::cout << "Введите Y (отклонение от центра E, ширина окна будет 2*Y): ";
                std::cin >> y;

                std::cout << "\nЗапуск проверки бинарным поиском...\n";
                if (checker.needsImprovement(x, y)) {
                    std::cout << "РЕЗУЛЬТАТ: Генератор нуждается в доработке (слишком высокая плотность чисел)!\n";
                } else {
                    std::cout << "РЕЗУЛЬТАТ: Генератор работает отлично, подозрительных скоплений нет.\n";
                }
                break;
            }
            case 0:
                std::cout << "Завершение работы...\n";
                break;
            default:
                std::cout << "Неверный пункт меню!\n";
                break;
        }
    } while (choice != 0);

    return 0;
}
