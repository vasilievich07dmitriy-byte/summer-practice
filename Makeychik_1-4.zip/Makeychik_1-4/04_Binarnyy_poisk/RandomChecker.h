﻿#ifndef RANDOM_CHECKER_H
#define RANDOM_CHECKER_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>

class RandomChecker {
private:
    std::vector<int> numbers;

    int findUpperBound(int target) const {
        int left = 0;
        int right = numbers.size();

        while (left < right) {
            int mid = left + (right - left) / 2;
            if (numbers[mid] <= target) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        return left;
    }

public:
    RandomChecker() = default;

    void generateRandom(int n, int minVal = 0, int maxVal = 100) {
        numbers.clear();
        for (int i = 0; i < n; ++i) {
            numbers.push_back(minVal + rand() % (maxVal - minVal + 1));
        }
    }

    void setNumbers(const std::vector<int>& input) {
        numbers = input;
    }

    bool needsImprovement(int x, int y) {
        if (numbers.empty() || x <= 0) {
            return false;
        }

        std::sort(numbers.begin(), numbers.end());

        int windowWidth = 2 * y;

        for (size_t i = 0; i < numbers.size(); ++i) {
            int maxAllowedValue = numbers[i] + windowWidth;

            int rightIndex = findUpperBound(maxAllowedValue);

            int countInWindow = rightIndex - i;

            if (countInWindow >= x) {
                std::cout << "\n[!] Найдено скопление: в интервале ["
                          << numbers[i] << "; " << maxAllowedValue
                          << "] находится " << countInWindow << " чисел (при пороге X = " << x << ").\n";
                return true;
            }
        }

        return false;
    }

    void printNumbers() const {
        if (numbers.empty()) {
            std::cout << "[ Массив пуст ]\n";
            return;
        }
        for (int num : numbers) {
            std::cout << num << " ";
        }
        std::cout << "\n";
    }

    size_t size() const {
        return numbers.size();
    }
};

#endif
