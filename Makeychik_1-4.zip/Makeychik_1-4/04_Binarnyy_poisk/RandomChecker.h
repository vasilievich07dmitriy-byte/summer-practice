﻿#ifndef RANDOM_CHECKER_H
#define RANDOM_CHECKER_H

#include <iostream>
#include <vector>
#include <algorithm> // Для std::sort
#include <cstdlib>
#include <ctime>

class RandomChecker {
private:
    std::vector<int> numbers;

    /**
     * @brief Ручная реализация бинарного поиска верхней границы (Upper Bound).
     * Находит индекс первого элемента, который СТРОГО БОЛЬШЕ target.
     */
    int findUpperBound(int target) const {
        int left = 0;
        int right = numbers.size();

        while (left < right) {
            int mid = left + (right - left) / 2;
            if (numbers[mid] <= target) {
                left = mid + 1; // Ищем правее
            } else {
                right = mid;    // Ищем левее
            }
        }
        return left;
    }

public:
    RandomChecker() = default;

    // Заполнение массива случайными числами
    void generateRandom(int n, int minVal = 0, int maxVal = 100) {
        numbers.clear();
        for (int i = 0; i < n; ++i) {
            numbers.push_back(minVal + rand() % (maxVal - minVal + 1));
        }
    }

    // Ручной ввод массива чисел
    void setNumbers(const std::vector<int>& input) {
        numbers = input;
    }

    /**
     * @brief Основная проверка качества генератора с помощью бинарного поиска.
     * @param x Минимальное количество чисел, вызывающее подозрение.
     * @param y Радиус интервала (ширина окна равна 2 * y).
     * @return true, если генератор НУЖДАЕТСЯ в доработке, иначе false.
     */
    bool needsImprovement(int x, int y) {
        if (numbers.empty() || x <= 0) {
            return false;
        }

        // 1. Сортируем массив по возрастанию
        std::sort(numbers.begin(), numbers.end());

        // 2. Для каждого числа ищем, сколько элементов попадает в окно [numbers[i], numbers[i] + 2*y]
        int windowWidth = 2 * y;

        for (size_t i = 0; i < numbers.size(); ++i) {
            int maxAllowedValue = numbers[i] + windowWidth;

            // Используем бинарный поиск, чтобы найти правый край окна
            int rightIndex = findUpperBound(maxAllowedValue);

            // Количество элементов в окне
            int countInWindow = rightIndex - i;

            if (countInWindow >= x) {
                std::cout << "\n[!] Найдено скопление: в интервале [" 
                          << numbers[i] << "; " << maxAllowedValue 
                          << "] находится " << countInWindow << " чисел (при пороге X = " << x << ").\n";
                return true; // Генератор плохой
            }
        }

        return false; // Всё в порядке, скоплений нет
    }

    void printNumbers() const {
        if (numbers.empty()) {
            std::cout << "[ Массив пуст ]\n";
            return;
        }
        for (int num : numbers) {
            std::cout << num << " ";
        }
        std::cout << "\n";
    }

    size_t size() const {
        return numbers.size();
    }
};

#endif // RANDOM_CHECKER_H
